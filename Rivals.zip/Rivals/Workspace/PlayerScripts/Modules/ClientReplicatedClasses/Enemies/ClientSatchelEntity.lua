-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ClientEnemy = require(Players.LocalPlayer.PlayerScripts.Modules.ClientReplicatedClasses.ClientEntity.ClientHumanoidEntity.ClientEnemy);
local u1 = setmetatable({}, ClientEnemy);
u1.__index = u1;

function u1.new(...) -- Line: 8
    -- upvalues: ClientEnemy (copy), u1 (copy)
    local v2 = ClientEnemy.new(...);
    local v3 = setmetatable(v2, u1);
    v3.AimAssistBlacklist = true;
    v3:_Init();

    return v3;
end;

function u1._Init(p4) -- Line: 28
end;

return u1;