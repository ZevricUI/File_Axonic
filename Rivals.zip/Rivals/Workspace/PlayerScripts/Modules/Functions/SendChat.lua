-- Decompiled with Potassium's decompiler.

local TextChatService = game:GetService("TextChatService");
local StarterGui = game:GetService("StarterGui");
local Players = game:GetService("Players");
local ComplianceController = require(Players.LocalPlayer.PlayerScripts.Controllers:WaitForChild("ComplianceController"));
local u1;

if TextChatService.ChatVersion == Enum.ChatVersion.TextChatService then
    u1 = Instance.new("TextChannel");
    u1.Name = "ServerMessageChannel";
    u1.Parent = TextChatService:WaitForChild("TextChannels");

    function u1.OnIncomingMessage(p2) -- Line: 13
        local TextChatMessageProperties = Instance.new("TextChatMessageProperties");
        local Text = p2.Text;
        local Metadata = p2.Metadata;

        if Metadata then
            Text = Metadata .. Text .. "</font>";
        end;

        TextChatMessageProperties.Text = Text;

        return TextChatMessageProperties;
    end;
else
    u1 = nil;
end;

return function(p3) -- Line: 30
    -- upvalues: ComplianceController (copy), TextChatService (copy), StarterGui (copy), u1 (ref)
    local v4 = typeof(p3) == "table";
    local v5 = "Argument 1 invalid, expected a table, got " .. tostring(p3);
    assert(v4, v5);

    if ComplianceController:IsChina() then
        return;
    end;

    if TextChatService.ChatVersion == Enum.ChatVersion.LegacyChatService then
        p3.Text = p3.Text or string.rep("?", 16);
        p3.Color = p3.Color or Color3.fromRGB(0, 0, 0);
        p3.Font = p3.Font or Enum.Font.GothamMedium;
        p3.TextSize = p3.TextSize or 14;
        StarterGui:SetCore("ChatMakeSystemMessage", p3);

        return;
    end;

    p3.Text = p3.Text or "???????????????????????????????????????????????????????????";
    p3.Font = p3.Font or Enum.Font.GothamBold;
    p3.TextSize = p3.TextSize or 14;
    local v6 = typeof(p3.Color) == "Color3" and p3.Color;

    if not v6 then
        if typeof(p3.Color) == "string" then
            v6 = Color3.fromHex(p3.Color);
        else
            v6 = false;
        end;
    end;

    p3.Color = v6;
    Color3.new();
    local v7 = "<font";

    if p3.Color then
        v7 = v7 .. " color=\"rgb(" .. math.floor(p3.Color.R * 255) .. "," .. math.floor(p3.Color.G * 255) .. "," .. math.floor(p3.Color.B * 255) .. ")\"";
    end;

    if p3.Font then
        local v8;

        if typeof(p3.Font) == "EnumItem" then
            v8 = p3.Font.Name;
        else
            v8 = tostring(p3.Font);
        end;

        v7 = v7 .. " face=\"" .. v8 .. "\"";
    end;

    if p3.TextSize then
        v7 = v7 .. " size=\"" .. p3.TextSize .. "\"";
    end;

    u1:DisplaySystemMessage(p3.Text, v7 .. ">");
end;