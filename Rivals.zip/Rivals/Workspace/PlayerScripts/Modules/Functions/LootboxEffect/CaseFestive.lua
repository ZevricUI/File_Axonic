-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Utility = require(ReplicatedStorage.Modules.Utility);

return function(p1) -- Line: 5
    -- upvalues: Utility (copy)
    Utility:CreateSound("rbxassetid://116041480514859", 1, 1, p1.HumanoidRootPart, true);
    wait(0.9);
    Utility:CreateSound("rbxassetid://18184413727", 1, 1, p1.HumanoidRootPart, true);
    wait(0.55);
    Utility:CreateSound("rbxassetid://18184413727", 1, 1, p1.HumanoidRootPart, true);
    wait(0.3);
    Utility:CreateSound("rbxassetid://140156477314761", 1, 1, p1.HumanoidRootPart, true);
end;