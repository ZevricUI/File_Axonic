-- Decompiled with Potassium's decompiler.

return {
    TerrainMaterials = {},
    TerrainProperties = {},
    LightingProperties = {
        ClockTime = 0,
        FogEnd = 100,
        Ambient = Color3.fromRGB(200, 189, 124),
        FogColor = Color3.fromRGB(0, 0, 0)
    },
    SoundServiceProperties = {
        AmbientReverb = Enum.ReverbType.Hallway
    }
};