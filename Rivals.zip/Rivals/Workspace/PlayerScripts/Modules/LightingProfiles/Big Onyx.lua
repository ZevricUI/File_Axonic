-- Decompiled with Potassium's decompiler.

return {
    TerrainMaterials = {},
    TerrainProperties = {},
    LightingProperties = {
        GeographicLatitude = 101,
        ColorShift_Top = Color3.fromRGB(255, 183, 0),
        Ambient = Color3.fromRGB(255, 255, 255),
        FogColor = Color3.fromRGB(0, 0, 0)
    },
    SoundServiceProperties = {}
};