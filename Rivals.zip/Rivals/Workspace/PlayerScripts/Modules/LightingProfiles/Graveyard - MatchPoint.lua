-- Decompiled with Potassium's decompiler.

return {
    TerrainMaterials = {},
    TerrainProperties = {},
    LightingProperties = {
        Brightness = 3,
        ClockTime = 7.893,
        EnvironmentDiffuseScale = 1,
        EnvironmentSpecularScale = 1,
        ExposureCompensation = -0.42,
        FogEnd = 100000,
        FogStart = 0,
        GeographicLatitude = 6.262,
        ShadowSoftness = 0.5,
        Ambient = Color3.fromRGB(58, 61, 58),
        ColorShift_Bottom = Color3.fromRGB(120, 213, 179),
        ColorShift_Top = Color3.fromRGB(66, 115, 86),
        FogColor = Color3.fromRGB(192, 192, 192),
        OutdoorAmbient = Color3.fromRGB(44, 45, 37)
    },
    SoundServiceProperties = {}
};