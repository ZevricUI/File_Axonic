-- Decompiled with Potassium's decompiler.

return {
    TerrainMaterials = {},
    TerrainProperties = {},
    LightingProperties = {},
    SoundServiceProperties = {}
};