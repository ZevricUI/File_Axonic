-- Decompiled with Potassium's decompiler.

return {
    TerrainMaterials = {},
    TerrainProperties = {},
    LightingProperties = {
        Brightness = 10,
        EnvironmentDiffuseScale = 1,
        EnvironmentSpecularScale = 1,
        ShadowSoftness = 1,
        ClockTime = 6.6,
        GeographicLatitude = 15.016,
        ExposureCompensation = -0.5,
        Ambient = Color3.fromRGB(141, 129, 129),
        ColorShift_Bottom = Color3.fromRGB(255, 183, 146),
        ColorShift_Top = Color3.fromRGB(255, 179, 125),
        OutdoorAmbient = Color3.fromRGB(214, 161, 160)
    },
    SoundServiceProperties = {}
};