-- Decompiled with Potassium's decompiler.

return {
    TerrainMaterials = {},
    TerrainProperties = {},
    LightingProperties = {
        Brightness = 3,
        EnvironmentDiffuseScale = 1,
        EnvironmentSpecularScale = 1,
        ShadowSoftness = 0.5,
        ClockTime = 12.026,
        GeographicLatitude = -39.552,
        ExposureCompensation = -0.42,
        Ambient = Color3.fromRGB(163, 172, 163),
        ColorShift_Bottom = Color3.fromRGB(120, 213, 179),
        ColorShift_Top = Color3.fromRGB(66, 115, 86),
        OutdoorAmbient = Color3.fromRGB(81, 83, 68)
    },
    SoundServiceProperties = {
        AmbientReverb = Enum.ReverbType.Alley
    }
};