-- Decompiled with Potassium's decompiler.

return {
    Date = "January 17, 2025",
    Title = "UPDATE 9 🌉",
    Image = "rbxassetid://75234703218368",
    Code = nil,
    Name = script.Name,
    Changes = {
        { "Title", "🌉 NEW MAP" },
        { "Description", "The brand-new Bridge map is here!" },
        { "Description", "Enter this arena-style duel zone located in Seoul, Korea!" },
        { "Description", "Made by @GreatGuyBoom!" },
        { "Title", "🔥 NEW SPECIAL CHALLENGES!" },
        { "Description", "The Winter Spotlight has been removed and replaced with a brand new set of challenges!" },
        { "Description", "Complete a series of tasks on the new Bridge map to earn keys & the limited time Bungeoppang charm!" },
        { "Title", "🛠 OTHER" },
        { "Description", "The Demon Shorty & Demon Uzi skins have been slightly modified" },
        { "Description", "The Hexxed Flare Gun skin, Hexxed Candle skin, and Hexxed wrap have been renamed to Vexed Flare Gun, Vexed Candle, & Vexed respectively" },
        { "Title", "📜 A NOTE FROM THE DEVELOPERS" },
        { "Description", "Hey everyone! We hope you enjoy this brand new map as we celebrate our Korean community!" },
        { "Description", "Now that the holiday season is over, our next major content update will be the long-awaited Ranked update!" },
        { "Description", "We also want to quickly mention that we purposely chose not to include any bug fixes, balance changes, & other quality of life additions this update. We hear all of your feedback and want to reassure you all that every necessary & additional changes/improvements will be made in time for Ranked!" }
    }
};