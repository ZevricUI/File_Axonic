-- Decompiled with Potassium's decompiler.

return {
    Date = "June 28, 2024",
    Title = "RELEASE 🎉",
    Image = "rbxassetid://18431449936",
    Code = nil,
    Name = script.Name,
    Changes = { { "Title", "Thanks for playing! :-)" } }
};