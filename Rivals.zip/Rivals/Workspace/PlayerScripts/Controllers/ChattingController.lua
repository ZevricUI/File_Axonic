-- Decompiled with Potassium's decompiler.

game:GetService("ReplicatedStorage");
local TextChatService = game:GetService("TextChatService");
local StarterGui = game:GetService("StarterGui");
local Players = game:GetService("Players");
local SpectateController = require(Players.LocalPlayer.PlayerScripts.Controllers.SpectateController);
local DuelController = require(Players.LocalPlayer.PlayerScripts.Controllers.DuelController);
local u1 = { {
        Result = "GG ❤️",
        Words = { "ggez" },
        Messages = {}
    }, {
        Result = "you played well",
        Words = { "ur bad", "ur so bad", "you are so bad", "you are bad", "horrible" },
        Messages = {}
    }, {
        Result = "W update ❤️",
        Words = { "l update" },
        Messages = {}
    }, {
        Result = "well played 👍",
        Words = { "gg ez" },
        Messages = { "ez" }
    }, {
        Result = "nice loadout",
        Words = { "p2w", "pay to win", "pay 2 win" },
        Messages = {}
    } };
local u2 = {};
u2.__index = u2;

function u2._new() -- Line: 45
    -- upvalues: u2 (copy)
    local v3 = setmetatable({}, u2);
    v3._muted_user_ids = {};
    v3:_Init();

    return v3;
end;

function u2._UpdateChatBubblesEnabled(p4) -- Line: 65
    -- upvalues: TextChatService (copy), SpectateController (copy)
    TextChatService:WaitForChild("BubbleChatConfiguration").Enabled = not (SpectateController.CurrentDuelSubject and SpectateController.CurrentDuelSubject.IsRanked);
end;

function u2._DuelInterfaceBubble(p5, p6, p7) -- Line: 69
    -- upvalues: DuelController (copy)
    if not p6 or table.find(p5._muted_user_ids, p6.UserId) then
        return;
    end;

    local v8 = {};

    for _, v in pairs(DuelController.Objects) do
        if v:GetDueler(p6) then
            table.insert(v8, v);
        end;
    end;

    if #v8 == 0 then
        return;
    end;

    for _, v in pairs(v8) do
        v.DuelInterface.Scores:NewChatMessage(p6, p7);
    end;
end;

function u2._OnIncomingMessage(p9, p10) -- Line: 97
    -- upvalues: u1 (copy)
    if not p10.TextSource then
        return;
    end;

    local Text = p10.Text;
    local v11 = false;

    for _, v in pairs(u1) do
        if table.find(v.Messages, string.lower(Text)) then
            Text = v.Result;
            v11 = true;
            break;
        end;
    end;

    if not v11 then
        local v12;

        repeat
            v12 = false;

            for _, v in pairs(u1) do
                local v13 = v;

                for _, v2 in pairs(v.Words) do
                    local string_find_ret = string.find(string.lower(Text), v2);

                    if string_find_ret then
                        Text = string.sub(Text, 1, string_find_ret - 1) .. v13.Result .. string.sub(Text, string_find_ret + #v2);
                        v12 = true;
                    end;
                end;
            end;
        until not v12;
    end;

    if Text ~= p10.Text then
        local TextChatMessageProperties = Instance.new("TextChatMessageProperties");
        TextChatMessageProperties.Text = Text;

        return TextChatMessageProperties;
    end;
end;

function u2._Init(u14) -- Line: 145
    -- upvalues: TextChatService (copy), Players (copy), SpectateController (copy), StarterGui (copy)
    function TextChatService.OnIncomingMessage(p15) -- Line: 146
        -- upvalues: u14 (copy), Players (ref)
        local v16 = u14:_OnIncomingMessage(p15);

        if p15.Status == Enum.TextChatMessageStatus.Success then
            local v17 = p15.TextSource and p15.TextSource.UserId and Players:GetPlayerByUserId(p15.TextSource.UserId);
            local v18 = v16 and v16.Translation ~= "" and v16.Translation;

            if not v18 then
                if p15.Translation == "" then
                    v18 = nil;
                else
                    v18 = p15.Translation or nil;
                end;
            end;

            task.defer(u14._DuelInterfaceBubble, u14, v17, v18 or (v16 and v16.Text or p15.Text));
        end;

        return v16;
    end;

    SpectateController.DuelSubjectChanged:Connect(function() -- Line: 160
        -- upvalues: u14 (copy)
        u14:_UpdateChatBubblesEnabled();
    end);
    task.spawn(function() -- Line: 164
        -- upvalues: StarterGui (ref), u14 (copy)
        StarterGui:GetCore("PlayerMutedEvent").Event:Connect(function(p19) -- Line: 165
            -- upvalues: u14 (ref)
            if not table.find(u14._muted_user_ids, p19.UserId) then
                table.insert(u14._muted_user_ids, p19.UserId);
            end;
        end);
        StarterGui:GetCore("PlayerUnmutedEvent").Event:Connect(function(p20) -- Line: 171
            -- upvalues: u14 (ref)
            if table.find(u14._muted_user_ids, p20.UserId) then
                table.remove(u14._muted_user_ids, p20.UserId);
            end;
        end);
    end);
    task.defer(u14._UpdateChatBubblesEnabled, u14);
end;

return u2._new();